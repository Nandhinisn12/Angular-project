# angular-ivy-xfpsju

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/angular-ivy-xfpsju)